function [ind,indf] = get_index(d),
  ind= d.index;
  indf = d.findex;
